---
title: Intermediate
taxonomy:
    category: docs
---

### Chapter 2

# Intermediate

Delve deeper into more **complex** topics
